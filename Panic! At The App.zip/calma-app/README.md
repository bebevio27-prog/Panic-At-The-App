# Calma — App anti-attacchi di panico

Un'app front-end calmante per aiutare durante gli attacchi di panico.

## Funzionalità
- **Respiro guidato 4-7-8** con animazione visiva e tono binaurale
- **Grounding 5-4-3-2-1** per tornare nel presente
- Design notturno morbido, zero distrazioni

## Deploy su Vercel
1. Carica questa cartella su GitHub
2. Importa il repo su [vercel.com](https://vercel.com)
3. Clicca Deploy — nessuna configurazione necessaria

## Uso locale
Apri semplicemente `index.html` nel browser.
